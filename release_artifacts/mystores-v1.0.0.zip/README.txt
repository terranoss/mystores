﻿==================================================
 MyStore - E-Commerce & POS Management Application
 Version: 1.0.0
==================================================

Welcome to MyStore!

PACKAGE CONTENTS:
-----------------
1. web/                 Upload all files inside this folder to your cPanel or VPS web root.
2. documentation.html   Open this in your web browser for complete step-by-step setup instructions.

QUICK START INSTRUCTIONS:
-------------------------
1. Upload the 'web' folder to your cPanel public_html or subdomain folder.
2. Create an empty database in cPanel MySQL.
3. Open your browser and navigate to:
   https://your-domain.com/install
4. Follow the on-screen 4-step installer wizard.

For full instructions, open 'documentation.html'.
