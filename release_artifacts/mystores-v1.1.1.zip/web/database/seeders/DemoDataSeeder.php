<?php

namespace Database\Seeders;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\ShopeeStore;
use App\Models\ShopeeToken;
use App\Models\User;
use App\Models\Workspace;
use App\Models\WorkspaceMember;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DemoDataSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Get or create owner user
        $user = User::first();
        if (!$user) {
            $user = User::create([
                'name' => 'Store Owner',
                'email' => 'admin@mystores.com',
                'password' => bcrypt('password123'),
            ]);
        }

        // 2. Get or create primary workspace
        $workspace = Workspace::where('owner_user_id', $user->id)->first();
        if (!$workspace) {
            $workspace = Workspace::create([
                'name' => 'Main Retail Workspace',
                'owner_user_id' => $user->id,
                'public_id' => (string) Str::uuid(),
            ]);

            WorkspaceMember::firstOrCreate([
                'workspace_id' => $workspace->id,
                'user_id' => $user->id,
            ], [
                'role' => 'owner',
            ]);
        }

        // 3. Clean existing store-dependent tables safely
        $storeIds = ShopeeStore::where('workspace_id', $workspace->id)->pluck('id');
        $orderIds = Order::whereIn('store_id', $storeIds)->pluck('id');
        $productIds = Product::whereIn('store_id', $storeIds)->pluck('id');

        OrderItem::whereIn('order_id', $orderIds)->delete();
        Order::whereIn('id', $orderIds)->delete();
        ProductVariant::whereIn('product_id', $productIds)->delete();
        Product::whereIn('id', $productIds)->delete();
        ShopeeToken::whereIn('store_id', $storeIds)->delete();
        ShopeeStore::whereIn('id', $storeIds)->delete();

        // 4. Create 3 Multi-Marketplace Stores
        $storeShopee1 = ShopeeStore::create([
            'user_id' => $user->id,
            'workspace_id' => $workspace->id,
            'platform' => 'shopee',
            'shop_id' => 228840551,
            'shop_name' => 'Riverside Mini Market (Shopee)',
            'region' => 'MY',
            'is_active' => true,
            'vacation_mode' => false,
            'orders_synced_at' => now(),
        ]);

        ShopeeToken::create([
            'store_id' => $storeShopee1->id,
            'access_token' => 'demo_token_shopee_1',
            'refresh_token' => 'demo_refresh_shopee_1',
            'access_token_expires_at' => now()->addDays(14),
            'refresh_token_expires_at' => now()->addDays(30),
            'auth_expires_at' => now()->addDays(30),
            'last_refreshed_at' => now()->subHours(2),
        ]);

        $storeShopee2 = ShopeeStore::create([
            'user_id' => $user->id,
            'workspace_id' => $workspace->id,
            'platform' => 'shopee',
            'shop_id' => 339102774,
            'shop_name' => 'Damansara Retail Point (Shopee)',
            'region' => 'MY',
            'is_active' => true,
            'vacation_mode' => false,
            'orders_synced_at' => now(),
        ]);

        ShopeeToken::create([
            'store_id' => $storeShopee2->id,
            'access_token' => 'demo_token_shopee_2',
            'refresh_token' => 'demo_refresh_shopee_2',
            'access_token_expires_at' => now()->addDays(10),
            'refresh_token_expires_at' => now()->addDays(30),
            'auth_expires_at' => now()->addDays(30),
            'last_refreshed_at' => now()->subHours(5),
        ]);

        $storeLazada = ShopeeStore::create([
            'user_id' => $user->id,
            'workspace_id' => $workspace->id,
            'platform' => 'lazada',
            'shop_id' => 551028834,
            'shop_name' => 'SS2 Convenience Store (Lazada)',
            'region' => 'MY',
            'is_active' => true,
            'vacation_mode' => false,
            'orders_synced_at' => now(),
        ]);

        ShopeeToken::create([
            'store_id' => $storeLazada->id,
            'access_token' => 'demo_token_lazada_1',
            'refresh_token' => 'demo_refresh_lazada_1',
            'access_token_expires_at' => now()->addDays(20),
            'refresh_token_expires_at' => now()->addDays(60),
            'auth_expires_at' => now()->addDays(60),
            'last_refreshed_at' => now()->subDay(),
        ]);

        $stores = [$storeShopee1, $storeShopee2, $storeLazada];

        // 5. Create Grouped Inventory Products (15 Products across stores)
        $catalog = [
            ['name' => 'Miyazaki Ghibli Vinyl Figure 8cm', 'sku' => 'SKU-MGV-08', 'price' => 89.00, 'stock' => 120, 'variants' => ['Totoro', 'No Face', 'Calcifer']],
            ['name' => 'Rider Matcha Starter Kit', 'sku' => 'SKU-RM-KIT', 'price' => 142.50, 'stock' => 45, 'variants' => ['Ceremonial Grade', 'Standard Grade']],
            ['name' => 'Nissin Cup Ramen Bundle x12', 'sku' => 'SKU-NSR-12', 'price' => 64.20, 'stock' => 210, 'variants' => ['Seafood', 'Spicy Pork', 'Tom Yam']],
            ['name' => 'Travel Organiser Bag Large', 'sku' => 'SKU-TOB-LG', 'price' => 76.00, 'stock' => 85, 'variants' => ['Navy Blue', 'Charcoal Grey']],
            ['name' => 'USB-C Fast Charger 65W GaN', 'sku' => 'SKU-USB-65W', 'price' => 118.90, 'stock' => 64, 'variants' => ['White', 'Black']],
            ['name' => 'Ceramic Pour-Over Coffee Set', 'sku' => 'SKU-CPS-01', 'price' => 95.00, 'stock' => 38, 'variants' => ['Matte Black', 'Snow White']],
            ['name' => 'Wireless ANC Earbuds Pro', 'sku' => 'SKU-WEP-PRO', 'price' => 199.00, 'stock' => 92, 'variants' => ['White', 'Graphite']],
            ['name' => 'Bamboo Cutting Board Set (3 pcs)', 'sku' => 'SKU-BCB-02', 'price' => 54.75, 'stock' => 115, 'variants' => ['Natural Bamboo']],
            ['name' => 'Japanese Chef Knife 8 inch', 'sku' => 'SKU-CK-08', 'price' => 89.90, 'stock' => 28, 'variants' => ['Damascus Finish']],
            ['name' => 'Weighted Calming Blanket 7kg', 'sku' => 'SKU-WB-7K', 'price' => 168.00, 'stock' => 18, 'variants' => ['Dark Slate', 'Dusty Rose']],
            ['name' => 'Air Fryer 5.5L Digital Touch', 'sku' => 'SKU-AFD-55', 'price' => 249.00, 'stock' => 34, 'variants' => ['Emerald Green', 'Glossy Black']],
            ['name' => 'Kids Educational Tablet 10.1 inch', 'sku' => 'SKU-KLT-01', 'price' => 179.50, 'stock' => 52, 'variants' => ['Blue Bumper', 'Pink Bumper']],
            ['name' => 'Sports Insulated Water Bottle 1L', 'sku' => 'SKU-SWB-1L', 'price' => 39.90, 'stock' => 180, 'variants' => ['Midnight Black', 'Ocean Blue', 'Army Green']],
            ['name' => 'Egyptian Cotton Bed Sheet Queen', 'sku' => 'SKU-CBS-QN', 'price' => 129.00, 'stock' => 40, 'variants' => ['Pearl White', 'Steel Grey']],
            ['name' => 'Ultrasonic Aroma Diffuser 300ml', 'sku' => 'SKU-AD-300', 'price' => 58.40, 'stock' => 75, 'variants' => ['Light Wood Grain', 'Dark Walnut']],
        ];

        $allCreatedProducts = [];

        foreach ($stores as $sIdx => $store) {
            foreach ($catalog as $cIdx => $item) {
                $itemId = ($sIdx + 1) * 1000000 + ($cIdx + 1) * 100;
                $hasVariants = count($item['variants']) > 1;

                $prod = Product::create([
                    'store_id' => $store->id,
                    'item_id' => $itemId,
                    'item_name' => $item['name'],
                    'item_sku' => $item['sku'],
                    'category_id' => 1001,
                    'price' => $item['price'],
                    'stock' => $item['stock'] + ($sIdx * 5),
                    'has_variants' => $hasVariants,
                    'raw_response' => ['status' => 'NORMAL'],
                    'synced_at' => now(),
                    'needs_push' => false,
                ]);

                foreach ($item['variants'] as $vIdx => $vName) {
                    $modelId = $itemId + $vIdx + 1;
                    ProductVariant::create([
                        'product_id' => $prod->id,
                        'model_id' => $modelId,
                        'name' => $vName,
                        'price' => $item['price'] + ($vIdx * 5),
                        'stock' => round(($item['stock'] + ($sIdx * 5)) / count($item['variants'])),
                        'model_sku' => $item['sku'] . '-' . strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $vName), 0, 4)),
                        'raw_response' => ['model_status' => 'NORMAL'],
                    ]);
                }

                $allCreatedProducts[] = $prod;
            }
        }

        // 6. Generate 60+ Realistic Multi-Marketplace Orders spanning 30 days
        $buyers = [
            ['name' => 'Nurul Hidayah', 'city' => 'Kuala Lumpur', 'address' => 'No 15, Jalan Bukit Bintang, 55100 Kuala Lumpur'],
            ['name' => 'Ahmad Fikri', 'city' => 'Petaling Jaya', 'address' => 'Unit B-12-05, Damansara Uptown, 47400 Petaling Jaya, Selangor'],
            ['name' => 'Siti Rohani', 'city' => 'Johor Bahru', 'address' => '22 Jalan Skudai, Taman University, 81300 Johor Bahru'],
            ['name' => 'Tan Wei Ling', 'city' => 'Penang', 'address' => '88 Gurney Drive, 10250 Georgetown, Penang'],
            ['name' => 'Rajesh Kumar', 'city' => 'Shah Alam', 'address' => 'No 7, Seksyen 13, 40100 Shah Alam, Selangor'],
            ['name' => 'Syafiq Harun', 'city' => 'Kota Kinabalu', 'address' => 'Lot 45, Lorong Lintas, 88300 Kota Kinabalu, Sabah'],
            ['name' => 'Priscilla Tan', 'city' => 'Kuching', 'address' => '12 Jalan Padungan, 93100 Kuching, Sarawak'],
            ['name' => 'Daniel Chong', 'city' => 'Malacca', 'address' => 'No 101, Jalan Melaka Raya, 75000 Melaka'],
            ['name' => 'Hafiz Mansor', 'city' => 'Ipoh', 'address' => '54 Jalan Tambun, 31400 Ipoh, Perak'],
            ['name' => 'Yee Wen Lim', 'city' => 'Kuantan', 'address' => '18 Jalan Teluk Sisek, 25000 Kuantan, Pahang'],
        ];

        $statuses = [
            'READY_TO_SHIP',
            'READY_TO_SHIP',
            'PROCESSED',
            'PROCESSED',
            'SHIPPED',
            'SHIPPED',
            'SHIPPED',
            'COMPLETED',
            'COMPLETED',
            'COMPLETED',
            'UNPAID',
            'CANCELLED',
            'IN_CANCEL',
            'TO_RETURN',
        ];

        for ($i = 0; $i < 65; $i++) {
            $store = $stores[$i % count($stores)];
            $platform = $store->platform;
            $status = $statuses[$i % count($statuses)];
            $buyer = $buyers[$i % count($buyers)];
            
            // Generate order date between 1 and 28 days ago
            $daysAgo = ($i % 28);
            $orderDate = now()->subDays($daysAgo)->subHours($i % 24)->subMinutes(($i * 13) % 60);
            $paidDate = $status !== 'UNPAID' ? $orderDate->copy()->addMinutes(12) : null;
            $shipBy = $orderDate->copy()->addDays(2);

            $orderSn = ($platform === 'lazada' ? 'LZ' : 'SP') . (2600000000 + $i * 7919) . strtoupper(Str::random(4));

            $order = Order::create([
                'store_id' => $store->id,
                'order_sn' => $orderSn,
                'order_status' => $status,
                'total_amount' => 0, // will compute below
                'currency' => 'MYR',
                'buyer_username' => $buyer['name'],
                'shipping_address' => $buyer['address'],
                'ordered_at' => $orderDate,
                'paid_time' => $paidDate,
                'ship_by_date' => $shipBy,
                'cancel_reason' => $status === 'CANCELLED' ? 'Buyer requested cancellation: changed mind' : null,
                'raw_response' => ['demo' => true],
                'synced_at' => now(),
                'packed_verified_at' => in_array($status, ['SHIPPED', 'COMPLETED']) ? $orderDate->copy()->addHours(18) : null,
            ]);

            // Add 1 to 3 items per order
            $itemCount = 1 + ($i % 3);
            $orderTotal = 0;

            for ($k = 0; $k < $itemCount; $k++) {
                $catalogItem = $catalog[($i + $k * 3) % count($catalog)];
                $qty = 1 + (($i + $k) % 3);
                $price = $catalogItem['price'];
                $itemTotal = $price * $qty;
                $orderTotal += $itemTotal;

                OrderItem::create([
                    'order_id' => $order->id,
                    'item_id' => 1000000 + (($i + $k * 3) % count($catalog)) * 100,
                    'model_id' => 1000000 + (($i + $k * 3) % count($catalog)) * 100 + 1,
                    'item_name' => $catalogItem['name'],
                    'sku' => $catalogItem['sku'],
                    'quantity' => $qty,
                    'price' => $price,
                ]);
            }

            $order->update(['total_amount' => $orderTotal]);
        }
    }
}
