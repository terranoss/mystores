<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ShopeeBoostLog extends Model
{
    protected $fillable = [
        'store_id',
        'item_id',
        'item_name',
        'status',
        'message',
        'boosted_at',
    ];

    protected function casts(): array
    {
        return [
            'item_id' => 'integer',
            'boosted_at' => 'datetime',
        ];
    }

    public function store(): BelongsTo
    {
        return $this->belongsTo(ShopeeStore::class, 'store_id');
    }
}

