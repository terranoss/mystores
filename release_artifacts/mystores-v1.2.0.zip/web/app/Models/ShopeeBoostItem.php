<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ShopeeBoostItem extends Model
{
    protected $fillable = [
        'store_id',
        'product_id',
        'item_id',
        'priority_order',
        'is_active',
        'last_boosted_at',
        'cooldown_expires_at',
    ];

    protected function casts(): array
    {
        return [
            'item_id' => 'integer',
            'priority_order' => 'integer',
            'is_active' => 'boolean',
            'last_boosted_at' => 'datetime',
            'cooldown_expires_at' => 'datetime',
        ];
    }

    public function store(): BelongsTo
    {
        return $this->belongsTo(ShopeeStore::class, 'store_id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id');
    }
}

