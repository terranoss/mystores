<?php

namespace App\Services;

use App\Exceptions\StoreNotActiveException;
use App\Models\Product;
use App\Models\ShopeeBoostItem;
use App\Models\ShopeeBoostLog;
use App\Models\ShopeeStore;
use App\Models\User;
use EcomPHP\Shopee\Client;
use Illuminate\Auth\Access\AuthorizationException as AccessAuthorizationException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class ShopeeBoostService
{
    public const MAX_BOOST_SLOTS = 5;
    public const DEFAULT_COOLDOWN_SECONDS = 14400; // 4 hours

    public function __construct(
        private readonly ShopeeService $shopee,
        private readonly WorkspaceAccess $workspaceAccess,
    ) {}

    /**
     * @return list<ShopeeStore>
     */
    public function accessibleShopeeStores(User $user, ?int $storeId = null): array
    {
        $ids = $this->workspaceAccess->workspaceIdsFor($user);
        if ($ids === []) {
            $ids = [$this->workspaceAccess->ensurePersonalWorkspace($user)->id];
        }

        $query = ShopeeStore::query()
            ->whereIn('workspace_id', $ids)
            ->where('platform', 'shopee');

        if ($storeId !== null && $storeId > 0) {
            $query->where('id', $storeId);
        }

        return $query->get()->all();
    }

    public function requireShopeeStore(User $user, int $storeId): ShopeeStore
    {
        $store = ShopeeStore::query()->findOrFail($storeId);

        if (!$this->workspaceAccess->canAccessStore($user, $store)) {
            throw new AccessAuthorizationException('Forbidden.');
        }

        if (($store->platform ?? 'shopee') !== 'shopee') {
            throw ValidationException::withMessages(['store_id' => 'Store is not a Shopee store.']);
        }

        return $store;
    }

    /**
     * Get live boosted items from Shopee API, enriched with local product information.
     *
     * @return array<string, mixed>
     */
    public function getLiveStatus(ShopeeStore $store): array
    {
        if (!$store->is_active) {
            throw new StoreNotActiveException("Store #{$store->id} is inactive. Please re-link from the Dashboard.");
        }

        $response = $this->callWithTokenRetry($store, function ($client) {
            return $client->Product->getBoostedList();
        });

        $body = $this->unwrapShopeeResponse($response);
        $rawItemList = $body['item_list'] ?? [];

        $itemIds = array_map(fn ($item) => (int) ($item['item_id'] ?? 0), $rawItemList);
        $products = Product::query()
            ->where('store_id', $store->id)
            ->whereIn('item_id', $itemIds)
            ->get()
            ->keyBy('item_id');

        $activeSlots = [];
        foreach ($rawItemList as $index => $item) {
            $itemId = (int) ($item['item_id'] ?? 0);
            $coolDownSecond = (int) ($item['cool_down_second'] ?? self::DEFAULT_COOLDOWN_SECONDS);
            $expiresAt = Carbon::now()->addSeconds($coolDownSecond);
            $product = $products->get($itemId);

            // Sync cooldown expiry to local boost items table if present
            ShopeeBoostItem::query()
                ->where('store_id', $store->id)
                ->where('item_id', $itemId)
                ->update(['cooldown_expires_at' => $expiresAt]);

            $activeSlots[] = [
                'slot_index' => $index + 1,
                'item_id' => $itemId,
                'cool_down_second' => $coolDownSecond,
                'cooldown_expires_at' => $expiresAt->toIso8601String(),
                'product' => $product ? [
                    'id' => $product->id,
                    'item_name' => $product->item_name,
                    'item_sku' => $product->item_sku,
                    'price' => (float) $product->price,
                    'stock' => (int) $product->stock,
                ] : null,
            ];
        }

        return [
            'store_id' => $store->id,
            'shop_name' => $store->shop_name,
            'auto_boost_enabled' => (bool) $store->auto_boost_enabled,
            'max_slots' => self::MAX_BOOST_SLOTS,
            'active_count' => count($activeSlots),
            'available_slots' => max(0, self::MAX_BOOST_SLOTS - count($activeSlots)),
            'slots' => $activeSlots,
        ];
    }

    /**
     * Inspect active slots and refill expired ones from the rotation queue.
     *
     * @return array<string, mixed>
     */
    public function rotateQueueForStore(ShopeeStore $store): array
    {
        if (!$store->is_active || !$store->auto_boost_enabled) {
            return [
                'store_id' => $store->id,
                'boosted' => [],
                'skipped_count' => 0,
                'reason' => !$store->is_active ? 'store_inactive' : 'autopilot_disabled',
            ];
        }

        $response = $this->callWithTokenRetry($store, function ($client) {
            return $client->Product->getBoostedList();
        });

        $body = $this->unwrapShopeeResponse($response);
        $activeList = $body['item_list'] ?? [];
        $activeItemIds = array_map(fn ($item) => (int) ($item['item_id'] ?? 0), $activeList);

        $freeSlots = max(0, self::MAX_BOOST_SLOTS - count($activeItemIds));
        if ($freeSlots <= 0) {
            return [
                'store_id' => $store->id,
                'boosted' => [],
                'skipped_count' => 0,
                'reason' => 'no_slots_available',
            ];
        }

        // Candidates: active in queue, not currently boosting
        $candidates = ShopeeBoostItem::query()
            ->with('product')
            ->where('store_id', $store->id)
            ->where('is_active', true)
            ->whereNotIn('item_id', $activeItemIds)
            ->orderByRaw('CASE WHEN last_boosted_at IS NULL THEN 0 ELSE 1 END ASC')
            ->orderBy('last_boosted_at', 'asc')
            ->orderBy('priority_order', 'asc')
            ->get();

        $toBoost = [];
        $skippedCount = 0;

        foreach ($candidates as $candidate) {
            if (count($toBoost) >= $freeSlots) {
                break;
            }

            // Cooldown protection: skip if local record still shows cooldown in future
            if ($candidate->cooldown_expires_at && $candidate->cooldown_expires_at->isFuture()) {
                $skippedCount++;
                continue;
            }

            // Out-of-stock protection: skip if linked product has stock <= 0
            if ($candidate->product && (int) $candidate->product->stock <= 0) {
                $skippedCount++;
                continue;
            }

            $toBoost[] = $candidate;
        }

        if (empty($toBoost)) {
            return [
                'store_id' => $store->id,
                'boosted' => [],
                'skipped_count' => $skippedCount,
                'reason' => 'no_eligible_items',
            ];
        }

        $itemIdsToBoost = array_map(fn (ShopeeBoostItem $item) => (int) $item->item_id, $toBoost);
        $candidateMap = collect($toBoost)->keyBy('item_id');

        $boostResponse = $this->callWithTokenRetry($store, function ($client) use ($itemIdsToBoost) {
            return $client->Product->boostItem($itemIdsToBoost);
        });

        $boostBody = $this->unwrapShopeeResponse($boostResponse);
        $successList = $boostBody['success_list'] ?? [];
        $failureList = $boostBody['failure_list'] ?? [];

        $boostedItems = [];

        foreach ($successList as $successItem) {
            $itemId = (int) ($successItem['item_id'] ?? 0);
            $coolDown = (int) ($successItem['cool_down_second'] ?? self::DEFAULT_COOLDOWN_SECONDS);
            $expiresAt = Carbon::now()->addSeconds($coolDown);

            $candidate = $candidateMap->get($itemId);
            if ($candidate) {
                $candidate->update([
                    'last_boosted_at' => Carbon::now(),
                    'cooldown_expires_at' => $expiresAt,
                ]);
            }

            $itemName = $candidate?->product?->item_name;

            ShopeeBoostLog::create([
                'store_id' => $store->id,
                'item_id' => $itemId,
                'item_name' => $itemName,
                'status' => 'success',
                'message' => 'Boosted successfully',
                'boosted_at' => Carbon::now(),
            ]);

            $boostedItems[] = [
                'item_id' => $itemId,
                'status' => 'success',
                'cooldown_expires_at' => $expiresAt->toIso8601String(),
            ];
        }

        foreach ($failureList as $failedItem) {
            $itemId = (int) ($failedItem['item_id'] ?? 0);
            $reason = (string) ($failedItem['failed_reason'] ?? 'Unknown error');
            $candidate = $candidateMap->get($itemId);

            // If item failed because it is still in cooldown on Shopee side, set local cooldown
            if (stripos($reason, 'cool down') !== false || stripos($reason, 'cooldown') !== false) {
                $candidate?->update([
                    'cooldown_expires_at' => Carbon::now()->addSeconds(self::DEFAULT_COOLDOWN_SECONDS),
                ]);
            }

            $itemName = $candidate?->product?->item_name;

            ShopeeBoostLog::create([
                'store_id' => $store->id,
                'item_id' => $itemId,
                'item_name' => $itemName,
                'status' => 'failed',
                'message' => $reason,
                'boosted_at' => Carbon::now(),
            ]);
        }

        return [
            'store_id' => $store->id,
            'boosted' => $boostedItems,
            'skipped_count' => $skippedCount,
            'failures' => count($failureList),
        ];
    }

    /**
     * Manually trigger an immediate boost for a single product.
     *
     * @return array<string, mixed>
     */
    public function manualBoost(ShopeeStore $store, int $itemId): array
    {
        if (!$store->is_active) {
            throw new StoreNotActiveException("Store #{$store->id} is inactive. Please re-link from the Dashboard.");
        }

        $product = Product::query()
            ->where('store_id', $store->id)
            ->where('item_id', $itemId)
            ->first();

        $boostResponse = $this->callWithTokenRetry($store, function ($client) use ($itemId) {
            return $client->Product->boostItem([$itemId]);
        });

        $boostBody = $this->unwrapShopeeResponse($boostResponse);
        $successList = $boostBody['success_list'] ?? [];
        $failureList = $boostBody['failure_list'] ?? [];

        if (!empty($successList)) {
            $successItem = $successList[0];
            $coolDown = (int) ($successItem['cool_down_second'] ?? self::DEFAULT_COOLDOWN_SECONDS);
            $expiresAt = Carbon::now()->addSeconds($coolDown);

            ShopeeBoostItem::query()
                ->where('store_id', $store->id)
                ->where('item_id', $itemId)
                ->update([
                    'last_boosted_at' => Carbon::now(),
                    'cooldown_expires_at' => $expiresAt,
                ]);

            ShopeeBoostLog::create([
                'store_id' => $store->id,
                'item_id' => $itemId,
                'item_name' => $product?->item_name,
                'status' => 'success',
                'message' => 'Manual boost succeeded',
                'boosted_at' => Carbon::now(),
            ]);

            return [
                'status' => 'success',
                'item_id' => $itemId,
                'cooldown_expires_at' => $expiresAt->toIso8601String(),
                'cool_down_second' => $coolDown,
            ];
        }

        $failedReason = $failureList[0]['failed_reason'] ?? 'Shopee boost failed';

        // If cooldown error, record cooldown timestamp
        if (stripos($failedReason, 'cool down') !== false || stripos($failedReason, 'cooldown') !== false) {
            ShopeeBoostItem::query()
                ->where('store_id', $store->id)
                ->where('item_id', $itemId)
                ->update([
                    'cooldown_expires_at' => Carbon::now()->addSeconds(self::DEFAULT_COOLDOWN_SECONDS),
                ]);
        }

        ShopeeBoostLog::create([
            'store_id' => $store->id,
            'item_id' => $itemId,
            'item_name' => $product?->item_name,
            'status' => 'failed',
            'message' => $failedReason,
            'boosted_at' => Carbon::now(),
        ]);

        throw ValidationException::withMessages([
            'item_id' => "Boost failed: {$failedReason}",
        ]);
    }

    /**
     * Get the rotation queue items for a store.
     *
     * @return array<string, mixed>
     */
    public function getQueue(ShopeeStore $store): array
    {
        $items = ShopeeBoostItem::query()
            ->with(['product:id,store_id,item_id,item_name,price,stock,item_sku'])
            ->where('store_id', $store->id)
            ->orderBy('priority_order', 'asc')
            ->orderBy('id', 'asc')
            ->get();

        return [
            'store_id' => $store->id,
            'items' => $items->map(function (ShopeeBoostItem $item) {
                return [
                    'id' => $item->id,
                    'item_id' => (int) $item->item_id,
                    'priority_order' => (int) $item->priority_order,
                    'is_active' => (bool) $item->is_active,
                    'last_boosted_at' => $item->last_boosted_at?->toIso8601String(),
                    'cooldown_expires_at' => $item->cooldown_expires_at?->toIso8601String(),
                    'in_cooldown' => $item->cooldown_expires_at ? $item->cooldown_expires_at->isFuture() : false,
                    'product' => $item->product ? [
                        'id' => $item->product->id,
                        'item_name' => $item->product->item_name,
                        'item_sku' => $item->product->item_sku,
                        'price' => (float) $item->product->price,
                        'stock' => (int) $item->product->stock,
                    ] : null,
                ];
            }),
        ];
    }

    /**
     * Add products to the store's boost queue.
     *
     * @param  list<int|string>  $itemIds
     * @return list<ShopeeBoostItem>
     */
    public function addToQueue(ShopeeStore $store, array $itemIds): array
    {
        $maxOrder = (int) ShopeeBoostItem::query()
            ->where('store_id', $store->id)
            ->max('priority_order');

        $created = [];

        foreach ($itemIds as $rawItemId) {
            $itemId = (int) $rawItemId;
            if ($itemId <= 0) {
                continue;
            }

            $product = Product::query()
                ->where('store_id', $store->id)
                ->where('item_id', $itemId)
                ->first();

            $maxOrder++;

            $item = ShopeeBoostItem::query()->firstOrCreate(
                [
                    'store_id' => $store->id,
                    'item_id' => $itemId,
                ],
                [
                    'product_id' => $product?->id,
                    'priority_order' => $maxOrder,
                    'is_active' => true,
                ]
            );

            // If it already existed but had missing product_id, refresh it
            if ($product && !$item->product_id) {
                $item->update(['product_id' => $product->id]);
            }

            $created[] = $item;
        }

        return $created;
    }

    /**
     * Update priority order of queue items.
     *
     * @param  list<int>  $orderedIds
     */
    public function reorderQueue(ShopeeStore $store, array $orderedIds): void
    {
        DB::transaction(function () use ($store, $orderedIds) {
            foreach ($orderedIds as $index => $id) {
                ShopeeBoostItem::query()
                    ->where('store_id', $store->id)
                    ->where('id', $id)
                    ->update(['priority_order' => $index + 1]);
            }
        });
    }

    /**
     * Toggle the active status of an individual queue item.
     */
    public function toggleQueueItem(ShopeeStore $store, int $id, bool $isActive): ShopeeBoostItem
    {
        $item = ShopeeBoostItem::query()
            ->where('store_id', $store->id)
            ->where('id', $id)
            ->firstOrFail();

        $item->update(['is_active' => $isActive]);

        return $item;
    }

    /**
     * Remove an item from the queue.
     */
    public function removeFromQueue(ShopeeStore $store, int $id): void
    {
        ShopeeBoostItem::query()
            ->where('store_id', $store->id)
            ->where('id', $id)
            ->delete();
    }

    /**
     * Toggle the store's auto-pilot setting.
     */
    public function toggleAutopilot(ShopeeStore $store, ?bool $enabled = null): ShopeeStore
    {
        $newState = $enabled !== null ? $enabled : !$store->auto_boost_enabled;
        $store->update(['auto_boost_enabled' => $newState]);

        return $store;
    }

    /**
     * Get recent boost operation audit logs.
     *
     * @return list<array<string, mixed>>
     */
    public function getLogs(ShopeeStore $store, int $limit = 50): array
    {
        return ShopeeBoostLog::query()
            ->where('store_id', $store->id)
            ->orderBy('boosted_at', 'desc')
            ->orderBy('id', 'desc')
            ->limit(min($limit, 200))
            ->get()
            ->map(fn (ShopeeBoostLog $log) => [
                'id' => $log->id,
                'item_id' => (int) $log->item_id,
                'item_name' => $log->item_name,
                'status' => $log->status,
                'message' => $log->message,
                'boosted_at' => $log->boosted_at->toIso8601String(),
            ])
            ->all();
    }

    /**
     * Unwraps response arrays from the Shopee client.
     *
     * @return array<string, mixed>
     */
    private function unwrapShopeeResponse(mixed $response): array
    {
        if (!is_array($response)) {
            return [];
        }

        if (isset($response['response']) && is_array($response['response'])) {
            return $response['response'];
        }

        return $response;
    }

    /**
     * Run a Shopee API call with token refresh retry support.
     */
    private function callWithTokenRetry(ShopeeStore $store, callable $callback): mixed
    {
        return $this->shopee->callWithTokenRetry(
            $store,
            $callback,
            fn (string $message): \Throwable => new StoreNotActiveException($message)
        );
    }
}
