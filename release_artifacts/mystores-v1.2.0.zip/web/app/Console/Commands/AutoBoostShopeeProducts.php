<?php

namespace App\Console\Commands;

use App\Models\ShopeeStore;
use App\Services\ShopeeBoostService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class AutoBoostShopeeProducts extends Command
{
    protected $signature = 'shopee:auto-boost {--store= : Boost only a specific store by ID} {--force : Force rotation even if auto_boost_enabled is false}';

    protected $description = 'Inspect active Shopee 4-hour boost slots and refill expired ones from the rotation queue';

    public function handle(ShopeeBoostService $boostService): int
    {
        $specificStoreId = $this->option('store');
        $force = (bool) $this->option('force');

        $query = ShopeeStore::query()
            ->where('platform', 'shopee')
            ->where('is_active', true);

        if (!$force) {
            $query->where('auto_boost_enabled', true);
        }

        if ($specificStoreId) {
            $query->where('id', $specificStoreId);
        }

        $stores = $query->orderBy('id')->get();

        if ($stores->isEmpty()) {
            $this->warn($specificStoreId ? 'Store not found, inactive, or auto-boost disabled.' : 'No active Shopee stores with auto-boost enabled.');
            return self::SUCCESS;
        }

        $this->info("Processing Shopee auto-boost for {$stores->count()} store(s)...");

        foreach ($stores as $store) {
            $this->line("Rotating queue for Store #{$store->id} ({$store->shop_name})...");

            try {
                $result = $boostService->rotateQueueForStore($store);
                $boostedCount = count($result['boosted'] ?? []);
                $skippedCount = (int) ($result['skipped_count'] ?? 0);
                $reason = $result['reason'] ?? 'completed';

                if ($boostedCount > 0) {
                    $this->info("  ✓ Store #{$store->id}: Boosted {$boostedCount} item(s) (skipped {$skippedCount}).");
                } else {
                    $this->comment("  - Store #{$store->id}: No items boosted ({$reason}, skipped {$skippedCount}).");
                }
            } catch (\Throwable $e) {
                Log::error("Shopee auto-boost failed for Store #{$store->id}: {$e->getMessage()}", [
                    'store_id' => $store->id,
                    'exception' => $e,
                ]);
                $this->error("  ✗ Store #{$store->id} error: {$e->getMessage()}");
            }
        }

        $this->info('Shopee auto-boost run complete.');
        return self::SUCCESS;
    }
}

