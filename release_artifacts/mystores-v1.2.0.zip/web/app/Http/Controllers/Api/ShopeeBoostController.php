<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\StoreNotActiveException;
use App\Http\Controllers\Controller;
use App\Models\ShopeeStore;
use App\Services\ShopeeBoostService;
use App\Services\WorkspaceActivityLogger;
use EcomPHP\Shopee\Errors\ShopeeException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class ShopeeBoostController extends Controller
{
    public function __construct(
        private readonly ShopeeBoostService $boostService,
        private readonly WorkspaceActivityLogger $activityLogger,
    ) {}

    /**
     * Get live status of boost slots (Shopee API).
     */
    public function status(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'nullable|integer|min:1',
        ]);

        $user = $request->user();
        $accessibleStores = $this->boostService->accessibleShopeeStores($user);

        if (empty($accessibleStores)) {
            return response()->json([
                'stores' => [],
                'status' => null,
            ]);
        }

        $storeId = $validated['store_id'] ?? $accessibleStores[0]->id;
        $store = $this->boostService->requireShopeeStore($user, (int) $storeId);

        try {
            $status = $this->boostService->getLiveStatus($store);
        } catch (StoreNotActiveException $e) {
            return response()->json([
                'message' => $e->getMessage(),
                'store_id' => $store->id,
                'is_active' => false,
            ], 422);
        } catch (ShopeeException $e) {
            return response()->json([
                'message' => 'Shopee API Error: ' . $e->getMessage(),
                'store_id' => $store->id,
            ], 502);
        }

        return response()->json([
            'stores' => array_map(fn (ShopeeStore $s) => [
                'id' => $s->id,
                'shop_name' => $s->shop_name,
                'is_active' => (bool) $s->is_active,
                'auto_boost_enabled' => (bool) $s->auto_boost_enabled,
            ], $accessibleStores),
            'status' => $status,
        ]);
    }

    /**
     * Get queue items and recent boost logs.
     */
    public function queue(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|integer|min:1',
        ]);

        $store = $this->boostService->requireShopeeStore($request->user(), (int) $validated['store_id']);
        $queueData = $this->boostService->getQueue($store);
        $logs = $this->boostService->getLogs($store, 50);

        return response()->json([
            'queue' => $queueData['items'],
            'logs' => $logs,
        ]);
    }

    /**
     * Add items to the rotation queue.
     */
    public function addToQueue(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|integer|min:1',
            'item_ids' => 'required|array|min:1',
            'item_ids.*' => 'required|integer',
        ]);

        $store = $this->boostService->requireShopeeStore($request->user(), (int) $validated['store_id']);
        $added = $this->boostService->addToQueue($store, $validated['item_ids']);

        $this->activityLogger->log(
            $request->user(),
            'shopee.boost.queue.add',
            "Added " . count($added) . " item(s) to Shopee boost queue for {$store->shop_name}",
            $store
        );

        return response()->json([
            'message' => 'Added ' . count($added) . ' product(s) to boost queue.',
            'count' => count($added),
        ]);
    }

    /**
     * Reorder queue items.
     */
    public function reorderQueue(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|integer|min:1',
            'ordered_ids' => 'required|array|min:1',
            'ordered_ids.*' => 'required|integer',
        ]);

        $store = $this->boostService->requireShopeeStore($request->user(), (int) $validated['store_id']);
        $this->boostService->reorderQueue($store, $validated['ordered_ids']);

        return response()->json([
            'message' => 'Queue reordered successfully.',
        ]);
    }

    /**
     * Toggle queue item active status.
     */
    public function toggleQueueItem(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|integer|min:1',
            'is_active' => 'required|boolean',
        ]);

        $store = $this->boostService->requireShopeeStore($request->user(), (int) $validated['store_id']);
        $item = $this->boostService->toggleQueueItem($store, $id, (bool) $validated['is_active']);

        return response()->json([
            'message' => 'Queue item updated.',
            'item' => $item,
        ]);
    }

    /**
     * Delete queue item.
     */
    public function deleteQueueItem(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|integer|min:1',
        ]);

        $store = $this->boostService->requireShopeeStore($request->user(), (int) $validated['store_id']);
        $this->boostService->removeFromQueue($store, $id);

        return response()->json([
            'message' => 'Queue item removed.',
        ]);
    }

    /**
     * On-demand manual boost for a single item.
     */
    public function manualBoost(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|integer|min:1',
            'item_id' => 'required|integer',
        ]);

        $store = $this->boostService->requireShopeeStore($request->user(), (int) $validated['store_id']);

        try {
            $result = $this->boostService->manualBoost($store, (int) $validated['item_id']);

            $this->activityLogger->log(
                $request->user(),
                'shopee.boost.manual',
                "Manually boosted item #{$validated['item_id']} in {$store->shop_name}",
                $store
            );

            return response()->json([
                'message' => 'Product boosted successfully!',
                'result' => $result,
            ]);
        } catch (StoreNotActiveException $e) {
            return response()->json(['message' => $e->getMessage()], 422);
        } catch (ShopeeException $e) {
            return response()->json(['message' => 'Shopee error: ' . $e->getMessage()], 502);
        }
    }

    /**
     * On-demand rotation trigger for a store (or all accessible stores).
     */
    public function rotate(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'nullable|integer|min:1',
        ]);

        $user = $request->user();
        $stores = isset($validated['store_id'])
            ? [$this->boostService->requireShopeeStore($user, (int) $validated['store_id'])]
            : $this->boostService->accessibleShopeeStores($user);

        $results = [];
        foreach ($stores as $store) {
            try {
                $results[] = $this->boostService->rotateQueueForStore($store);
            } catch (\Throwable $e) {
                $results[] = [
                    'store_id' => $store->id,
                    'error' => $e->getMessage(),
                ];
            }
        }

        return response()->json([
            'message' => 'Rotation processed.',
            'results' => $results,
        ]);
    }

    /**
     * Toggle auto-pilot on/off for a store.
     */
    public function toggleAutopilot(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'store_id' => 'required|integer|min:1',
            'enabled' => 'nullable|boolean',
        ]);

        $store = $this->boostService->requireShopeeStore($request->user(), (int) $validated['store_id']);
        $enabled = isset($validated['enabled']) ? (bool) $validated['enabled'] : null;
        $updated = $this->boostService->toggleAutopilot($store, $enabled);

        $stateLabel = $updated->auto_boost_enabled ? 'enabled' : 'disabled';
        $this->activityLogger->log(
            $request->user(),
            'shopee.boost.autopilot',
            "Auto-boost {$stateLabel} for {$store->shop_name}",
            $store
        );

        return response()->json([
            'message' => "Auto-pilot {$stateLabel} successfully.",
            'auto_boost_enabled' => (bool) $updated->auto_boost_enabled,
        ]);
    }
}
