<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('shopee_boost_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('store_id')->constrained('shopee_stores')->cascadeOnDelete();
            $table->foreignId('product_id')->nullable()->constrained('products')->nullOnDelete();
            $table->bigInteger('item_id');
            $table->unsignedInteger('priority_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamp('last_boosted_at')->nullable();
            $table->timestamp('cooldown_expires_at')->nullable();
            $table->timestamps();

            $table->unique(['store_id', 'item_id']);
            $table->index(['store_id', 'is_active', 'priority_order']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('shopee_boost_items');
    }
};

