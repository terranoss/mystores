<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('shopee_boost_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('store_id')->constrained('shopee_stores')->cascadeOnDelete();
            $table->bigInteger('item_id');
            $table->string('item_name')->nullable();
            $table->string('status', 20)->default('success');
            $table->text('message')->nullable();
            $table->timestamp('boosted_at')->useCurrent();
            $table->timestamps();

            $table->index(['store_id', 'boosted_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('shopee_boost_logs');
    }
};

